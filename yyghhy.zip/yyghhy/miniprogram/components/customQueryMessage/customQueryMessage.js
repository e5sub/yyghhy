Component({
  properties: {
    msg: Object,
    recording: Boolean // 语音输入时是否显示动图
  },

  data: {},
  lifetimes: {
    ready: function () { }
  },
  methods: {}
});
