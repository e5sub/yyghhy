Component({
  externalClasses: ['tui-loading-class'],
  properties: {
    text:{
      type: String,
      value: "正在加载..."
    },
    visible: {
      type: Boolean,
      value: false
    }
  },
  data: {
  },
  methods: {
  }
})