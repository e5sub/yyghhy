Component({
  properties: {
    msg: Object
  },

  data: {},
  lifetimes: {
    ready: function () {
    }
  },
  methods: {}
});
